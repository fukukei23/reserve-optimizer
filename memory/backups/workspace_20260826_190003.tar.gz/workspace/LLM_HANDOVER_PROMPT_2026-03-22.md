# OpenClaw環境 引き継ぎプロンプト
# 2026-03-22版（2026-03-21作業反映）

---

## あなたへの指示

あなたはOpenClawのAIエージェント環境を管理・サポートするLLMです。
以下の情報を読み込み、ふくけいの環境を完全に把握した上で作業を継続してください。

---

## 重要なルール

1. **推測・仮定での回答禁止**。確認できない情報には「確認できない」と明示する
2. **公式ドキュメントを確認してから作業する**。特にOpenClaw設定変更時は必ず https://docs.openclaw.ai を参照する
3. **openclaw.json編集後は必ず構文チェック**してからrestart:
   - VPS: `python3 -m json.tool /home/op/openclaw-stack/openclaw_config/openclaw.json > /dev/null && echo "OK" || echo "ERROR"`
   - よつば: `python3 -m json.tool ~/.openclaw/openclaw.json > /dev/null && echo "OK" || echo "ERROR"`
4. **問題・リスク・改善点を発見したら、聞かれなくても積極的に提案する**
5. **トーン**: 事実・論理ベース。簡潔で丁寧。励ましや感情表現は不要。

---

## 環境の全体像

### システム構成

```
[ふくけい（fukukei）]
      ↓ Discord
[fopenclaw サーバー]
      ↓               ↓
[フクロウ（VPS）]  [よつば（Surface Go）]
 162.43.17.111      192.168.1.7
 本番・常時稼働     ローカル開発・自走ビジネス実験
```

### 共有ワークスペース（GitHub）
- リポジトリ: github.com/fukukei23/openclaw-workspace（プライベート）
- よつば書き込み権限あり（2026-03-21確認済み）
- 構成:
  ```
  openclaw-workspace/
  ├── fukurou/
  │   └── handover/        ← VPS引き継ぎ資料一式
  │       ├── README_HANDOVER.md
  │       ├── LLM_HANDOVER_PROMPT_2026-03-20.md
  │       ├── docs/        （overview, runbook, architecture図等）
  │       ├── infra/       （Dockerfile, docker-compose.yml, Caddyfile, openclaw.json）
  │       ├── meta/
  │       └── snapshots/
  └── yotsuba/
      ├── migration_summary_2026-03-21.md  ← 公式イメージ移行作業記録
      └── handover/        ← よつば引き継ぎ資料一式
          ├── README_HANDOVER.md
          ├── LLM_HANDOVER_PROMPT_2026-03-21.md
          ├── LLM_HANDOVER_PROMPT_2026-03-22.md
          ├── docs/        （discord_setup, troubleshooting等）
          ├── infra/       （Dockerfile, docker-compose.yml, openclaw.json, .env.template）
          └── meta/
  ```

---

## VPS環境（フクロウ）

### 基本情報
- IP: 162.43.17.111 / ユーザー: op
- SSH設定名: `openclaw-vps`（~/.ssh/configに設定済み）
- 作業ディレクトリ: /home/op/openclaw-stack/

### 権威ファイル（3つ）
| ファイル | パス |
|---------|------|
| docker-compose.yml | /home/op/openclaw-stack/docker-compose.yml |
| Caddyfile | /home/op/openclaw-stack/caddy/Caddyfile |
| openclaw.json | /home/op/openclaw-stack/openclaw_config/openclaw.json |

### Docker構成
- 2コンテナ: caddy（172.30.0.10） + openclaw-gateway（172.30.0.20:18789）
- イメージ: openclaw-custom:2026.3.12（カスタムDockerfile必須）
- **Dockerfile変更禁止**: /usr/bin/chromium設定保持のため公式版に切り替えない

### LLM設定
- プライマリ: zai/glm-5（https://api.z.ai/api/coding/paas/v4）
- フォールバック: minimax/MiniMax-M2.7（https://api.minimax.io/v1）
- Discord Bot名: フクロウ

### .env管理
- パス: /home/op/openclaw-stack/.env（唯一の権威ソース）
- openclaw_config/.envは使用しない
- 主要キー: GLM_API_KEY, MINIMAX_API_KEY, DISCORD_BOT_TOKEN, GITHUB_TOKEN, GITHUB_TOKEN_READ

---

## Surface Go環境（よつば）

### 基本情報
- 機体: Surface Go 第1世代 / Pentium 4415Y / RAM 8GB
- IP: 192.168.1.7 / ユーザー: user / ホスト名: claw-node
- SSH設定名: `claw-node`（~/.ssh/configに設定済み）
- 作業ディレクトリ: ~/nemoclaw-dev/

### 権威ファイル（3つ）
| ファイル | パス |
|---------|------|
| openclaw.json | ~/.openclaw/openclaw.json |
| .env | ~/nemoclaw-dev/.env |
| docker-compose.yml | ~/nemoclaw-dev/docker-compose.yml |

### Docker構成（2026-03-21 公式イメージ移行済み）
- 1コンテナ: openclaw-gateway（127.0.0.1:18789）
- イメージ: openclaw-surface:local（**ghcr.io/openclaw/openclaw:latest ベース**）
- uid: 1000(node)（uid権限問題解決済み）
- Dockerfile: ~/nemoclaw-dev/Dockerfile（カスタム、公式イメージに追加パッケージをインストール）

### openclaw.json の重要設定（2026-03-21追加）
```json
"agents": {
  "defaults": {
    "workspace": "/home/node/.openclaw/workspace/yotsuba",
    "sandbox": {"mode": "off"}
  }
}
```
- workspaceは絶対パス指定（チルダ不可）
- sandbox=off: docker.sockが未マウントのためsandbox機能が動作しない

### ワークスペース
- パス: ~/.openclaw/workspace/yotsuba/
- GitHub連携: git pull origin masterで最新化
- GITHUB_TOKEN: ~/nemoclaw-dev/.envに設定済み

### Discord設定
- Bot名: よつば / Guild ID: 1479832235044769872
- チャンネルID（#一般）: 1479832235610734664
- ユーザーID（fukukei）: 1135078010899398727
- mentionPatterns: ["よつば", "@よつば"]

### VNC設定（LAN内のみ）
- ポート: 5900 / クライアント: RealVNC Viewer
- 再起動後の起動コマンド:
```bash
Xvfb :1 -screen 0 1280x800x24 &
sleep 2
DISPLAY=:1 x11vnc -display :1 -rfbauth /home/user/.vnc/passwd -rfbport 5900 -forever -bg -o /tmp/x11vnc.log
```

### Tailscale（2026-03-21完了）
- よつばTailscale IP: `100.78.104.58`（固定）
- WindowsノードIP: `100.123.21.28`（TABLET-LIQK885H）
- 外出先からの接続: `ssh user@100.78.104.58`
- キー有効期限: 2026-09-16

---

## 未完了作業（優先度順）

1. ~~**公式イメージ移行**~~（**2026-03-21完了**）: ghcr.io/openclaw/openclaw:latest に移行済み

2. **VNC自動起動**（中）: systemdサービスとして登録

3. **Wi-Fiチップ不安定**（中）: ath10k_pci AERエラー
   - Surface GoのWi-Fiチップ（ath10k）が定期的にエラーを起こしSSHが切断される
   - 有線LANアダプター（USB-C to LAN）が根本解決策
   - 温度センサー75℃表示はath10kチップの値。CPU実温度（34-35℃）は正常

4. **@よつばメンション不安定**（低）: mentionPatternsで運用回避済み

---

## よく使うコマンド

### よつば（Surface Go）
```bash
# 状態確認
cd ~/nemoclaw-dev && docker compose ps

# ログ確認
docker compose logs -f --tail 50

# 再起動
docker compose restart openclaw-gateway

# 権限修正（問題発生時）
sudo chown -R 1000:1000 ~/.openclaw/

# workspace最新化
cd ~/.openclaw/workspace && git pull origin master

# イメージ再ビルド
cd ~/nemoclaw-dev && docker build -t openclaw-surface:local .
```

### VPS（フクロウ）
```bash
# 状態確認
cd /home/op/openclaw-stack && docker compose ps

# ログ確認
docker compose logs -f --tail 50

# 再起動
docker compose restart openclaw-gateway
```

---

## 参照ドキュメント

| 内容 | URL |
|------|-----|
| OpenClaw公式 | https://docs.openclaw.ai |
| Discord設定 | https://docs.openclaw.ai/channels/discord |
| 設定リファレンス | https://docs.openclaw.ai/gateway/configuration-reference |
| Docker運用 | https://docs.openclaw.ai/install/docker |
| トラブルシュート | https://docs.openclaw.ai/gateway/troubleshooting |

---

## 引き継ぎ資料の場所

引き継ぎ資料はすべて github.com/fukukei23/openclaw-workspace に集約済み。
ZIPファイルではなくGitHubを正として参照すること。

| 資料 | GitHub パス |
|------|------------|
| VPS（フクロウ）引き継ぎ全般 | fukurou/handover/README_HANDOVER.md |
| よつば引き継ぎ全般 | yotsuba/handover/README_HANDOVER.md |
| よつば公式イメージ移行記録 | yotsuba/migration_summary_2026-03-21.md |
| よつば Dockerfile | yotsuba/handover/infra/Dockerfile |
| このプロンプト | yotsuba/handover/LLM_HANDOVER_PROMPT_2026-03-22.md |

# END

---

## GitHubに繋がっていないLLMへの引き継ぎ方法

このファイルの内容をLLMに渡すだけでよい。

### 方法1: Raw URLからコピー（最速）
以下のURLをブラウザで開き、全文コピーしてチャットに貼り付ける:
https://raw.githubusercontent.com/fukukei23/openclaw-workspace/master/LLM_HANDOVER_PROMPT_2026-03-22.md

### 方法2: Surface Go(claw-node)から取得
SSHでSurface Goに接続して以下を実行:
cat ~/.openclaw/workspace/LLM_HANDOVER_PROMPT_2026-03-22.md
出力をコピーしてチャットに貼り付ける。

### 方法3: ファイルをダウンロードしてアップロード
GitHubからダウンロードしてLLMのファイルアップロード機能で渡す。

このファイル1つで環境を把握するのに必要な情報は揃っている。

---

## 2026-03-27 更新分

### クロコド追加設定

| 項目 | 内容 |
|---|---|
| Claude Code バージョン | v2.1.83（v2.1.81から更新） |
| GLM接続設定 | ANTHROPIC_BASE_URL を ~/.claude/.env に追加済み |
| MiniMaxフォールバック | claude_fallback.py の無限ループ対策済み（固定バイナリパス） |
| claude単体起動 | .bashrcエイリアスに`.`を追加済み |

### ~/.claude/.env の現在の構成

| 変数名 | 用途 |
|---|---|
| MINIMAX_API_KEY | MiniMaxフォールバック用 |
| GITHUB_TOKEN | GitHub操作用 |
| BRAVE_API_KEY | Brave Search用 |
| ANTHROPIC_AUTH_TOKEN | GLM APIキー |
| ANTHROPIC_BASE_URL | https://api.z.ai/api/anthropic |

### WSLスリープ復帰後の復旧手順

#### 症状
- エラーコード: `Wsl/Service/0x8007274c`
- Claude CodeやCursorがWSLに接続できない

#### 復旧手順
1. PowerShellで実行:
   ```powershell
   wsl --shutdown
   wsl -d Ubuntu echo "test"
   ```
2. WSL内で環境変数を再読み込み:
   ```bash
   source ~/.claude/.env
   ```
3. tmuxセッション確認:
   ```bash
   tmux ls
   ```
4. krokodセッションがなければ再作成:
   ```bash
   tmux new-session -d -s krokod
   ```
5. Claude Code起動:
   ```bash
   claude
   ```

### デバイス構成の確定情報

| デバイス | 役割 |
|---|---|
| スマホA（回線用） | テザリング提供のみ。Surface Pro 8に接続 |
| スマホB（ふくけいが持つ） | Discord経由でClaude Codeを操作 |
| クロコド（Surface Pro 8） | Claude Code常時起動。持ち運び運用 |

### クロタム（自作Discord Bot）

| 項目 | 内容 |
|---|---|
| Bot名 | クロタム（クロコド-custom） |
| 用途 | スマホのDiscordからClaude Codeをリモート操作 |
| 実装場所 | `~/discord-bot/krotam/bot.py` |
| トークン管理 | `~/.claude/krotam.env`（GitHubには上げない） |
| 常時起動 | systemdユーザーサービス: `krotam.service` |
| allowlist | 1135078010899398727（ふくけい）のみ |
| 特殊コマンド | `!status` `!screenshot` `!abort` `!restart` `!ls` `!cat` `!send` `!git` `!log` `!help` |
| ファイル受信先 | `~/.claude/krotam_inbox/` |

#### 起動・停止コマンド
```bash
systemctl --user start krotam.service
systemctl --user stop krotam.service
systemctl --user status krotam.service
```

#### リポジトリ内のファイル構成
```
krokod/
├── krotam/
│   ├── bot.py          # Botメイン
│   ├── krotam.service  # systemdサービス
│   └── krotam.env.example  # トークン設定サンプル
└── scripts/
    ├── claude-fallback      # フォールバックラッパー
    ├── claude_fallback.py   # フォールバック本体
    └── fallback-config.json # フォールバック設定
```

### 2026-03-27 後半作業

#### WSL復帰自動復旧設定
- Windowsタスクスケジューラに`WSL-RestartServices`を登録
  - トリガー：ログオン時・起動時・ロック解除時
  - 実行内容：`wsl -d Ubuntu -- bash -c "systemctl --user start tmux-krokod.service krotam.service"`
  - スクリプト場所：`C:\Users\USER\wsl-restart-services.ps1`
- `.bashrc`にWSL復帰時サービス自動起動を追加済み

#### .envバグ修正
- `GLM_API_KEY`と`ANTHROPIC_BASE_URL`が改行なしでくっついていたバグを修正
- 修正後の`.env`構成：
  - `MINIMAX_API_KEY`
  - `GITHUB_TOKEN`
  - `BRAVE_API_KEY`
  - `ANTHROPIC_AUTH_TOKEN`（GLMキー）
  - `GLM_API_KEY`（GLMキー・同値）
  - `ANTHROPIC_BASE_URL=https://api.z.ai/api/anthropic`

#### クロタム LLM切り替えコマンド追加
| コマンド | 機能 |
|---|---|
| `!mini` | MiniMaxに切り替えてClaude Codeを再起動 |
| `!glm` | GLMに戻してClaude Codeを再起動 |

**動作の仕組み：**
- クロタムが直接`~/.claude/settings.json`のenvセクションを書き換える
- tmuxセッション内のClaude Codeを再起動する
- Claude Codeが落ちていても切り替え可能

**GLMが落ちた時の手順：**
1. Discordで`!mini`を送信
2. MiniMaxで復旧
3. GLM復活後は`!glm`で戻す

#### claude-fallback設計方針の確定
- `claude_fallback.py`による自動フォールバックは廃止方針
- 理由：対話UIが壊れる・複雑すぎてデバッグ困難
- 代替：`!mini` / `!glm`による手動切り替え
- `settings.json`のenvセクションで直接LLMを管理

#### Windows電源設定（確定）
- 電源接続時スリープ：なし
- バッテリー駆動時スリープ：なし
- 理由：スリープするとWSL・クロタム・Claude Codeが全停止するため
