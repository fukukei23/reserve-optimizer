# USER.md - About Your Human

_Learn about the person you're helping. Update this as you go._

- **Name:** ふくけい
- **What to call them:** ふくけい
- **Pronouns:** _(optional)_
- **Timezone:** Asia/Tokyo (UTC+9)
- **Notes:** 全ての会話・報告は日本語で行う。

## Context

_(What do they care about? What projects are they working on? What annoys them? What makes them laugh? Build this over time.)_

---

The more you know, the better you can help. But remember — you're learning about a person, not building a dossier. Respect the difference.
